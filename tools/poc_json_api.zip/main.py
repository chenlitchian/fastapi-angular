from typing import Any, Dict
from fastapi import FastAPI, HTTPException,Request, Body

app = FastAPI()

@app.get("/api")
async def read_request_header(request: Request):
    my_header = dict()
    for x in request.headers.keys():
        if x == 'x-user-id':
            my_header[x]=request.headers.get(x)
    return {"data": my_header }

from pydantic import BaseModel

@app.get("/api/reports")
async def get_reports(request: Request):
    print('get report api')
    my_header = dict()
    for x in request.headers.keys():
        if x == 'x-user-id':
            my_header[x]=request.headers.get(x)
            
    my_report = dict(name='reportA', value='report_A')
    reports = list()
    reports.append(my_report)
    reports.append(dict(name='reportB', value='report_B'))
    return {"reports": reports }

class Item(BaseModel):
    name: str


@app.post('/api/test')
def main(user: Dict[Any, Any] = None):
    print(user)
    return user

@app.post("/api")
async def read_request_header(name: str = Body(...)):
     # request json body
    print(name)
    return {'name':name}

    # if request is None:
    #     raise HTTPException(status_code=500, detail="Internal Server Error")
    
    # print("Received request with headers:")
    # for header, value in request.headers.items():
    #     print(f"{header}: {value}")
    # print(request.headers)
    # print(request.headers.values.)
    # print(request.headers.keys)
    # print(request.headers)
    # print(request.headers)
    # print(request.headers)
    # print(request.headers.items)
    # my_header = dict()
    # for x in request.headers.keys():
    #     my_header[x]=request.headers.get(x)
    # for x in request.body.:
    #     my_header[x]=request.headers.get(x)
    # return {"message": "Request headers printed successfully"}
    # return {"data": item }
